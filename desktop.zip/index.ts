import { contextBridge } from 'electron';

// Capturar el argumento pasado desde main
const backendArg = process.argv.find(arg => arg.includes('BACKEND_URL='));
const baseURL = backendArg ? backendArg.split('=')[1] : 'http://localhost:4000';

console.log('Usando BACKEND_URL desde preload:', baseURL);

contextBridge.exposeInMainWorld('electronAPI', {
  getHero: async () => {
    try {
      const response = await fetch(`${baseURL}/home`);
      if (!response.ok) throw new Error(`Error ${response.status}: ${response.statusText}`);
      return await response.json();
    } catch (error) {
      console.error('Error al obtener Hero:', error);
      return null;
    }
  },
});
