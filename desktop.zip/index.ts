import { app, BrowserWindow } from 'electron';
import * as path from 'path';
import * as dotenv from 'dotenv';

// Cargar las variables del archivo .env desde la raíz del proyecto
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const baseURL = process.env.VITE_BACKEND_URL || 'http://localhost:4000';

// Pasar también como switch adicional por seguridad
app.commandLine.appendSwitch('BACKEND_URL', baseURL);

const createWindow = () => {
  console.log('Valor de process.env.VITE_BACKEND_URL:', process.env.VITE_BACKEND_URL);
  console.log('Argumento enviado a preload:', `--BACKEND_URL=${baseURL}`);

  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.resolve(__dirname, '../../preload/dist/index.js'),
      additionalArguments: [`--BACKEND_URL=${baseURL}`],
    },
  });

  win.loadURL('http://localhost:5173');
  win.webContents.openDevTools();
};

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
